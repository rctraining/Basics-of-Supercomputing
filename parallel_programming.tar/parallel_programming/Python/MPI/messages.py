#!/usr/bin/env python
def main():
    """
    Python, mpi4py parallel hello world.
    """

    from mpi4py import MPI
    import sys

    num_proc  = MPI.COMM_WORLD.Get_size()
    my_rank   = MPI.COMM_WORLD.Get_rank()
    node_name = MPI.Get_processor_name()
    comm = MPI.COMM_WORLD

    if (my_rank == 0):
        sys.stdout.write("  %d MPI Processes are now active.\n" %(num_proc))
    comm.Barrier()

    token = my_rank


    if(my_rank == 0):
        #rank 0 receives a message from rank num_proc-1
        my_source = num_proc-1  # the sender's rank
        my_tag = num_proc-1     # a unique identifier for this message (must match sender's tag))

        token = comm.recv(source=my_source, tag=my_tag) #token is overwritten by value sent from num_proc-1      
        sys.stdout.write("  Rank %d has received the token from rank %d.\n"% (my_rank, my_source));
        sys.stdout.write(
            "  Token pass complete!\n")
    if (my_rank == (num_proc-1)):
        #rank num_proc-1 sends the value of token to rank 0
        my_dest = 0  # the receivers rank
        my_tag = my_rank # a unique identifer (must match what receiver expects)
        comm.send(token, dest=my_dest, tag=my_tag)

    MPI.COMM_WORLD.Disconnect()
main()

