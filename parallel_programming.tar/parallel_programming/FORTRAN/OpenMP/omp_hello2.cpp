#include <stdio.h>
#include <omp.h>

int main(int argc, char** argv) {
    // Print a hello world message from the main thread.
    printf("  Hello world from the only processor here so far!\n");

    #pragma omp parallel
    {
        // Code inside this region runs in parallel.
        int thread_id;
        int num_threads;

        thread_id = omp_get_thread_num();
        num_threads = omp_get_num_threads();
        if (num_threads > 1)
        {
            if (thread_id == 0)
            {
                printf("  %d threads are now active.\n", num_threads);
            }
            printf("  Hello world from thread %d.\n",thread_id);
        }

    }
}

