#include <stdio.h>
#include <omp.h>
//omp.h must always be included in c++ programs.

int main(int argc, char** argv) {

    // Print a hello world message from the main thread.
    printf("  Hello from the only process here so far!\n");

    // At this point in the program, only a single thread is active,
    // and the program behaves as a serial code.

    #pragma omp parallel 
    {
    // Code inside this region runs in parallel.
    int thread_id; // Each thread has a unique copy of this variable

    //Each thread has a unique identifying number, which we store in thread_id
    thread_id = omp_get_thread_num();
    printf("  Hello from thread %d.\n",thread_id);

    }
}

