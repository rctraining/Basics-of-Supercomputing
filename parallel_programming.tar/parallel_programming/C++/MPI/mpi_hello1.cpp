#include <stdio.h>
#include <mpi.h> //We always include mpi.h when running MPI programs in C++
int main(int argc, char** argv) {
    int num_proc;  // The number of processes
    int my_rank; // the rank of this process (ranges from 0-nproc-1) 
    // The next string will hold the node's name.
    // Note that the value of MPI_MAX_PROCESSOR_NAME is defined by the MPI distribution
    char node_name[MPI_MAX_PROCESSOR_NAME]; // string to hold the node's name (e.g., shas0118)
    int name_len; // the number of characters in node_name
    MPI_Init(NULL, NULL);  // Initialize MPI

    // Find number of MPI processes
    MPI_Comm_size(MPI_COMM_WORLD, &num_proc);

    // Find this process's rank
    MPI_Comm_rank(MPI_COMM_WORLD, &my_rank);

    // Find the name of this node
    MPI_Get_processor_name(node_name, &name_len);

   
    printf("  Hello world from processor %s, rank %d out of %d processors.\n",
         node_name, my_rank, num_proc);

    // Once we're finished, we call MPI_finalize.  No further calls to MPI can be made once MPI_Finalize is invoked.
    MPI_Finalize();
  
}

