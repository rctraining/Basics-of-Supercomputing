#include <stdio.h>
#include <mpi.h>
int main(int argc, char** argv) {
    int num_proc;  // The number of processes
    int my_rank; // the rank of this process (ranges from 0-nproc-1) 
    // The next string will hold the node's name.
    // Note that the value of MPI_MAX_PROCESSOR_NAME is defined by the MPI distribution
    char node_name[MPI_MAX_PROCESSOR_NAME]; // string to hold the node's name (e.g., shas0118)
    int name_len; // the number of characters in node_name
    int i;
    int token;
    

    MPI_Init(NULL, NULL);
    MPI_Comm_size(MPI_COMM_WORLD, &num_proc);
    MPI_Comm_rank(MPI_COMM_WORLD, &my_rank);
    MPI_Get_processor_name(node_name, &name_len);

    token = my_rank;

    if (my_rank == 0)
    {
        printf("  %d MPI Processes are now active.\n", num_proc);
    }
    MPI_Barrier(MPI_COMM_WORLD);

    if (my_rank > 0)
    {
        //receive a message from my_rank-1


        MPI_Recv(&token, 1, MPI_INT, my_rank-1, my_rank-1, MPI_COMM_WORLD,
             MPI_STATUS_IGNORE);
    }


    if (my_rank < (num_proc-1))
    {
        //send a message to my_rank+1
        MPI_Send(&token, 1, MPI_INT, my_rank+1, my_rank, MPI_COMM_WORLD);
    }


    if (my_rank == (num_proc-1))
    {
        //send a message to rank 0
        MPI_Send(&token, 1, MPI_INT, 0, my_rank, MPI_COMM_WORLD);
    }

    if (my_rank == 0)
    {
        //receive a message from rank num_proc-1


        MPI_Recv(&token, 1, MPI_INT, num_proc-1, num_proc-1, MPI_COMM_WORLD,
             MPI_STATUS_IGNORE);
        printf("  Token pass complete!\n");
    }

    
    MPI_Finalize();
  
}

