#include <stdio.h>
#include <mpi.h>
int main(int argc, char** argv) {
    int num_proc;  // The number of processes
    int my_rank; // the rank of this process (ranges from 0-nproc-1) 
    // The next string will hold the node's name.
    // Note that the value of MPI_MAX_PROCESSOR_NAME is defined by the MPI distribution
    char node_name[MPI_MAX_PROCESSOR_NAME]; // string to hold the node's name (e.g., shas0118)
    int name_len; // the number of characters in node_name
    int i;
    int token;
    int source, dest, tag, nvals;
    

    MPI_Init(NULL, NULL);
    MPI_Comm_size(MPI_COMM_WORLD, &num_proc);
    MPI_Comm_rank(MPI_COMM_WORLD, &my_rank);
    MPI_Get_processor_name(node_name, &name_len);

    token = my_rank;

    if (my_rank == 0)
    {
        printf("  %d MPI Processes are now active.\n", num_proc);
    }
    MPI_Barrier(MPI_COMM_WORLD);


    //In this example, we exchange a single integer value between rank num_proc-1 and rank 0

    if (my_rank == (num_proc-1))
    {
        //The highest rank sends a message to rank 0

        dest = 0;      // The destination rank
        tag = my_rank; // A unique tag for this message (destination should expect same tag)
        nvals = 1;     // The number of values we are transmitting

        //We send the value of the token variable
        MPI_Send(&token, nvals, MPI_INT, dest, tag, MPI_COMM_WORLD);
    }

    if (my_rank == 0)
    {
        //Rank 0 receives a message from rank num_proc-1
        source = num_proc-1;  // The source of the message
        tag = num_proc-1;     // The message tag (must match the tag  set by sender)
        nvals = 1;            // The number of values we will receive

        //The value of token will be overwritten by whatever num_proc-1 sends.
        MPI_Recv(&token, nvals, MPI_INT, source, tag, MPI_COMM_WORLD,
             MPI_STATUS_IGNORE);
        printf("  Rank %d has received the token from rank %d.\n", my_rank, source);
        printf("  Token pass complete!\n");
    }

    
    MPI_Finalize();
  
}

